
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const axios = require('axios');
const path = require('path');
const fs = require('fs');
const FormData = require('form-data');

const app = express();
app.use(cors());
app.use(express.static('src/outputs'));

const upload = multer({ dest: 'src/uploads/' });

app.get('/', (req, res) => {
  res.json({ message: "Vivanta backend is running" });
});

app.post('/upload', upload.single('file'), async (req, res) => {
  const file = req.file;
  const language = req.body.language || 'en';
  const filename = `dubbed-${Date.now()}.mp4`;
  const outputPath = path.join('src/outputs', filename);

  // Aquí se integrarán APIs reales:
  // 1. Transcribir con Whisper
  // 2. Separar voces con pyannote
  // 3. Traducir con DeepL
  // 4. Sintetizar voz con ElevenLabs
  // 5. Reensamblar con FFMPEG

  // Simulación temporal del pipeline real (para testear estructura)
  setTimeout(() => {
    fs.copyFileSync(file.path, outputPath);
    res.json({ final_video_path: `/download?filename=${filename}` });
  }, 6000);
});

app.get('/download', (req, res) => {
  const filename = req.query.filename;
  const filePath = path.join(__dirname, 'src/outputs', filename);
  if (fs.existsSync(filePath)) {
    res.download(filePath);
  } else {
    res.status(404).send('Video not found');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Vivanta backend is running at http://localhost:${PORT}`);
});
